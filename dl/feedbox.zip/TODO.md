# TODO

* Fix parsing problems
* Unread counter
* Pull updates via timer
* Testing
* FavIcons
* Inline-Editing

# Features

* Tag management